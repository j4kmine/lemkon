<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class lemkon extends CI_Controller {
		public function __construct()
        {
            parent::__construct();
            $this->load->database();
                    $this->db->db_select("db_lemkon");
            $this->load->helper('url');
            $this->load->library('grocery_CRUD');
                    $this->load->model("login_model");
                    /*if(!$this->login_model->isLogged()){
                        redirect("/login");
                    }*/               
                    if($this->login_model->isLogged()){
                        $this->nama = $this->login_model->name();
                        $this->hakAkses= $this->login_model->hakAkses();
                        //echo "HI $name! You are Logged IN!";
                    }else{
                        redirect("/login");
                    }
        }

        private  $username;
        private  $nama;
        private  $hakAkses;
//--------------------------------------------- custom function --------------------------------------------
private function gabungKalimat($kalimat,$chara){
    $temp = explode($chara,$kalimat);
    $result="";
    foreach ($temp as $word){
        $result .= $word;
    }
    return $result;
} 
//--------------------------------------------- End of custom function -------------------------------------
//--------------------------------------------- callback function ------------------------------------------

public function pelepasliaran_unindef_callback($post_array){
    $post_array['id_histori_lepas'] = $post_array['id_satwa_noniden']."-".$post_array['tgl_pelepasliaran'];
    $post_array['id_histori_lepas'] = str_replace("/","_",$post_array['id_histori_lepas']);
    $post_array['id_histori_lepas'] = str_replace(" ","-",$post_array['id_histori_lepas']);
    return $post_array;
}

public function satwa_kelompok_callback($post_array){
    $post_array['id_satwa_noniden'] = $post_array['informasi_lk_umum_kode_lk']."-".$post_array['master_satwa_nama_latin'];
    $post_array['id_satwa_noniden'] = str_replace("/","_",$post_array['id_satwa_noniden']);
    $post_array['id_satwa_noniden'] = str_replace(" ","-",$post_array['id_satwa_noniden']);

    $this->load->model("histori_perolehan_noniden");
    $tgl_perolehan = date('Y-m-d');
    $this->histori_perolehan_noniden->insertPerolehanSatwa($post_array['id_satwa_noniden'], $tgl_perolehan, "AWL", $post_array['informasi_lk_umum_kode_lk'], $post_array['informasi_lk_umum_kode_lk'], $post_array['jumlah_jantan'], $post_array['jumlah_betina'], $post_array['jumlah_unknown']);

    return $post_array;
}

public function perolehan_unindef_callback($post_array){
    $post_array['id_perolehan'] = $post_array['id_satwa_noniden']."-".$post_array['tgl_perolehan'];
    $post_array['id_perolehan'] = str_replace("/","_",$post_array['id_perolehan']);
    $post_array['id_perolehan'] = str_replace(" ","-",$post_array['id_perolehan']);
    return $post_array;
}

public function kematian_unindef_callback($post_array){
    
    $post_array['id_histori_mati'] = $post_array['id_satwa_noniden']."-".$post_array['tgl_kematian'];
    $post_array['id_histori_mati'] = str_replace("/","_",$post_array['id_histori_mati']);
    $post_array['id_histori_mati'] = str_replace(" ","-",$post_array['id_histori_mati']);
    return $post_array;
}

public function kelahiran_unindef_callback($post_array){
    
    $post_array['id_histori_lahir'] = $post_array['id_satwa_noniden']."-".$post_array['tgl_kelahiran'];
    $post_array['id_histori_lahir'] = str_replace("/","_",$post_array['id_histori_lahir']);
    $post_array['id_histori_lahir'] = str_replace(" ","-",$post_array['id_histori_lahir']);
    return $post_array;
}

function individu_satwa_callback($post_array){
    $post_array['id_individu_satwa'] = $post_array['informasi_lk_umum_id_lk']."-".$post_array['master_satwa_nama_latin']."-".$post_array['no_identifikasi'];  
    $post_array['id_individu_satwa'] = str_replace("/","_",$post_array['id_individu_satwa']);
    $post_array['id_individu_satwa'] = str_replace(" ","-",$post_array['id_individu_satwa']);
    
    $tanggal_perolehan = date('Y-m-d');
    $this->load->model("perolehan_satwa");
    $this->perolehan_satwa->insertPerolehanSatwa($post_array['id_individu_satwa'], "AWL", $tanggal_perolehan, $post_array['informasi_lk_umum_id_lk']);
    return $post_array;
}

function investasi_callback($post_array) {
    /*$this->load->library('encrypt');
    $key = 'super-secret-key';
    $post_array['password'] = $this->encrypt->encode($post_array['password'], $key);*/
    $post_array['modal_awal'] = $this->gabungKalimat($post_array['modal_awal'],",");
    $post_array['pegawai'] = $this->gabungKalimat($post_array['pegawai'],",");
    $post_array['sarana'] = $this->gabungKalimat($post_array['sarana'],",");
    //if(strlen($post_array['id_investasi'])<1){
        $post_array['id_investasi'] = $post_array['informasi_lk_umum_kode_lk']."-".$post_array['tanggal_update'];  
        $post_array['id_investasi'] = str_replace("/","_",$post_array['id_investasi']);
    return $post_array;
}   

public function perolehan_satwa_callback($post_array){
    $this->load->model("data_individu_satwa");//$idIndividu, $idLKTujuan
    $this->data_individu_satwa->updateLKSatwa($post_array['id_individu_satwa'], 
                                              $post_array['lk_tujuan_informasi_lk_umum_kode_lk']);
    //if(strlen($post_array['id_perolehan'])<1){
        $post_array['id_perolehan'] = $post_array['id_individu_satwa']."-".$post_array['tanggal_perolehan'];
        $post_array['id_perolehan'] = str_replace("/","_",$post_array['id_perolehan']);
        $post_array['id_perolehan'] = str_replace(" ","-",$post_array['id_perolehan']);
    //}
    return $post_array;
}

public function pelepasliaran_callback($post_array){
    $this->load->model("data_individu_satwa");//$idIndividu, $idLKTujuan
    $this->data_individu_satwa->updateLKSatwa($post_array['data_individu_satwa_master_satwa_nama_latin'], 
                                              "LEPAS");
                                              
    $post_array['id_pelepasliaran'] = $post_array['data_individu_satwa_master_satwa_nama_latin']."-".$post_array['tanggal_pelepasliaran'];
    $post_array['id_pelepasliaran'] = str_replace("/","_",$post_array['id_pelepasliaran']);
    $post_array['id_pelepasliaran'] = str_replace(" ","-",$post_array['id_pelepasliaran']);
    return $post_array;
}

public function currencyFormat($value, $row=null){    
    $result = number_format($value,2,",",".");
    return $result;
}  
//--------------------------------------------- End of callback function -----------------------------------
//--------------------------------------------- Transactional Function -------------------------------------
        public function monitoring_pelepasliaran_unindef(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Monitoring pelepasliaran Satwa Berkelompok";
            $req["url"]=site_url('lemkon/pelepasliaran_unindef_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function pelepasliaran_unindef_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('histori_pelepasliaran_noniden');             

                //warning kasih session juga
                $crud->set_relation("id_satwa_noniden","dinamika_satwa_noniden","{master_satwa_nama_latin} - {informasi_lk_umum_kode_lk}");

                $crud->display_as("id_satwa_noniden","Jenis Satwa")
                ->display_as("provinsi_id_prov","Provinsi Pelepasliaran")
                ->display_as("kabupaten_id_kab","Kabupaten Pelepasliaran")
                ->display_as("kecamatan_id_kecamatan","Kecamatan Pelepasliaran")
                ->display_as("kelurahan_id_lurah","Kelurahan Pelepasliaran")
                ;

                $crud->field_type('id_histori_lepas', 'hidden');

                $crud->columns('id_satwa_noniden',
                               'tgl_pelepasliaran',
                               'provinsi_id_prov',
                               'kabupaten_id_kab',
                               'jumlah_jantan',
                               'jumlah_betina',
                               'jumlah_unknown'
                );

                $crud->callback_before_insert(array($this,'pelepasliaran_unindef_callback'));
                $crud->callback_before_update(array($this,'pelepasliaran_unindef_callback'));
                
                $crud->set_relation("provinsi_id_prov", "provinsi", "nama_prov");
                $crud->set_relation("kabupaten_id_kab", "kabupaten", "nama_kab");
                $crud->set_relation("kecamatan_id_kecamatan", "kecamatan", "nama_kecamatan");
                $crud->set_relation("kelurahan_id_lurah", "kelurahan", "nama_lurah");

                $this->load->library('gc_dependent_select');
                
                $fields = array(
                        'provinsi_id_prov' => array(// first dropdown name
                        'table_name' => 'provinsi', // table of country
                        'title' => 'nama_prov', // country title
                        'relate' => null, // the first dropdown hasn't a relation
                        'data-placeholder' => 'Pilih Provinsi'
                        ),
                        'kabupaten_id_kab' => array(// second dropdown name
                        'table_name' => 'kabupaten', // table of state
                        'title' => 'nama_kab', // state title
                        'id_field' => 'id_kab', // table of state: primary key
                        'relate' => 'provinsi_id_prov', // table of state:
                        'data-placeholder' => 'Pilih Kabupaten/Kota' //dropdown's data-placeholder:
                        ),                        
                        'kecamatan_id_kecamatan' => array(// second dropdown name
                        'table_name' => 'kecamatan', // table of state
                        'title' => 'nama_kecamatan', // state title
                        'id_field' => 'id_kecamatan', // table of state: primary key
                        'relate' => 'kabupaten_id_kab', // table of state:
                        'data-placeholder' => 'Pilih Kecamatan' //dropdown's data-placeholder:
                        ),                    
                        'kelurahan_id_lurah' => array(// second dropdown name
                        'table_name' => 'kelurahan', // table of state
                        'title' => 'nama_lurah', // state title
                        'id_field' => 'id_lurah', // table of state: primary key
                        'relate' => 'kecamatan_id_kecamatan', // table of state:
                        'data-placeholder' => 'Pilih Kelurahan/Desa' //dropdown's data-placeholder:
                        ),
                    );
                
                $config = array(
                            'main_table' => 'histori_pelepasliaran_noniden',
                            'main_table_primary' => 'id_histori_lepas',
                            "url" => base_url() .'/index.php/'. __CLASS__ . '/' . __FUNCTION__ . '/',
                            'ajax_loader' => base_url() . '/assets/grocery_crud/themes/datatables/css/images/small-loading.gif'
                        );
                $categories = new gc_dependent_select($crud, $fields, $config);
                $js = $categories->get_js();
                
                $output = $crud->render();        
                $output->output.= $js;
                $this->displayCRUD($output);

                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_perolehan_unindef(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Monitoring Perolehan Satwa Berkelompok";
            $req["url"]=site_url('lemkon/perolehan_unindef_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function perolehan_unindef_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('histori_perolehan_noniden');             

                //warning kasih session juga
                $crud->set_relation("id_satwa_noniden","dinamika_satwa_noniden","master_satwa_nama_latin");
                $crud->set_relation("cara_perolehan","master_perolehan","cara_perolehan");
                $crud->set_relation("lk_tujuan","informasi_lk_umum","nama_lk");
                $crud->set_relation("lk_asal","informasi_lk_umum","nama_lk");

                $crud->display_as("id_satwa_noniden","Jenis Satwa");

                $crud->field_type('id_perolehan', 'hidden');

                $crud->unset_columns('id_perolehan');

                $crud->callback_before_insert(array($this,'perolehan_unindef_callback'));
                $crud->callback_before_update(array($this,'perolehan_unindef_callback'));
                
                $output = $crud->render();                        
                $this->displayCRUD($output);

                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_kematian_unindef(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Monitoring Kematian Satwa Berkelompok";
            $req["url"]=site_url('lemkon/kematian_unindef_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }        

        public function kematian_unindef_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('histori_kematian_noniden');             

                //warning kasih session juga
                $crud->set_relation("id_satwa_noniden","dinamika_satwa_noniden","{master_satwa_nama_latin} - {informasi_lk_umum_kode_lk}");
                $crud->set_relation("sebab_kematian","master_sebab_mati","nama_sebab");

                $crud->display_as("id_satwa_noniden","Jenis Satwa");

                $crud->field_type('id_histori_mati', 'hidden');

                $crud->unset_columns('id_histori_mati');

                $crud->callback_before_insert(array($this,'kematian_unindef_callback'));
                $crud->callback_before_update(array($this,'kematian_unindef_callback'));
                
                $output = $crud->render();                        
                $this->displayCRUD($output);

                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_kelahiran_unindef(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Monitoring Kelahiran Satwa Berkelompok";
            $req["url"]=site_url('lemkon/kelahiran_unindef_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function kelahiran_unindef_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('histori_kelahiran_noniden');             

                //warning kasih session juga
                $crud->set_relation("id_satwa_noniden","dinamika_satwa_noniden","{master_satwa_nama_latin} - {informasi_lk_umum_kode_lk}");

                $crud->display_as("id_satwa_noniden","Jenis Satwa");

                $crud->field_type('id_histori_lahir', 'hidden');
                $crud->unset_columns("id_histori_lahir");

                $crud->callback_before_insert(array($this,'kelahiran_unindef_callback'));
                $crud->callback_before_update(array($this,'kelahiran_unindef_callback'));
                
                $output = $crud->render();                        
                $this->displayCRUD($output);

                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_pelepasliaran(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Pelepasliaran Satwa";
            $req["url"]=site_url('lemkon/pelepasliaran_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function pelepasliaran_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('pelepasliaran');
                
                //warningg tambahin where dr LK session
                $crud->set_relation("data_individu_satwa_master_satwa_nama_latin","data_individu_satwa","{nama_panggilan_satwa} - {informasi_lk_umum_id_lk}/{master_satwa_nama_latin}");                                
                
                $crud->display_as("data_individu_satwa_informasi_lk_umum_id_lk","Nama LK")
                //->display_as("data_individu_satwa_no_identifikasi","No Identifikasi")
                //->display_as("data_individu_satwa_master_satwa_nama_latin","Nama Satwa")   
                ->display_as("upload_satdan","Upload SAT-DN") 
                ->display_as("provinsi_id_prov", "Provinsi Pelepasan")                    
                ->display_as("kabupaten_id_kab", "Kabupaten Pelepasan")                    
                ->display_as("kecamatan_id_kecamatan", "Kecamatan Pelepasan")                    
                ->display_as("kelurahan_id_lurah", "Kelurahan Pelepasan")                    
                ->display_as("latitude", "Latitude (decimal format)")                    
                ->display_as("longitude", "Longitude (decimal format)")                    
                ;

                $crud->field_type('id_pelepasliaran', 'hidden');

                $crud->unset_columns(//"kelurahan_id_lurah",
                //"kecamatan_id_kecamatan",
                "upload_satdan",
                "upload_persetujan_dj",
                "upload_foto_utuh",
                "upload_foto_spesifik",
                "id_pelepasliaran"
                );

                $crud->set_rules('latitude','Latitude (decimal format)','decimal');
                $crud->set_rules('longitude','Latitude (decimal format)','decimal');

                $crud->callback_before_insert(array($this,'pelepasliaran_callback'));
                $crud->callback_before_update(array($this,'pelepasliaran_callback'));

                $crud->set_field_upload('upload_satdan','assets/uploads/lk/satdnlepas');
                $crud->set_field_upload('upload_persetujan_dj','assets/uploads/lk/djlepas');
                $crud->set_field_upload('upload_foto_utuh','assets/uploads/lk/fulepas');
                $crud->set_field_upload('upload_foto_spesifik','assets/uploads/lk/fslepas');

                $crud->set_relation("provinsi_id_prov", "provinsi", "nama_prov");
                $crud->set_relation("kabupaten_id_kab", "kabupaten", "nama_kab");
                $crud->set_relation("kecamatan_id_kecamatan", "kecamatan", "nama_kecamatan");
                $crud->set_relation("kelurahan_id_lurah", "kelurahan", "nama_lurah");

                $this->load->library('gc_dependent_select');
                
                $fields = array(
                        'provinsi_id_prov' => array(// first dropdown name
                        'table_name' => 'provinsi', // table of country
                        'title' => 'nama_prov', // country title
                        'relate' => null, // the first dropdown hasn't a relation
                        'data-placeholder' => 'Pilih Provinsi'
                        ),
                        'kabupaten_id_kab' => array(// second dropdown name
                        'table_name' => 'kabupaten', // table of state
                        'title' => 'nama_kab', // state title
                        'id_field' => 'id_kab', // table of state: primary key
                        'relate' => 'provinsi_id_prov', // table of state:
                        'data-placeholder' => 'Pilih Kabupaten/Kota' //dropdown's data-placeholder:
                        ),                        
                        'kecamatan_id_kecamatan' => array(// second dropdown name
                        'table_name' => 'kecamatan', // table of state
                        'title' => 'nama_kecamatan', // state title
                        'id_field' => 'id_kecamatan', // table of state: primary key
                        'relate' => 'kabupaten_id_kab', // table of state:
                        'data-placeholder' => 'Pilih Kecamatan' //dropdown's data-placeholder:
                        ),                    
                        'kelurahan_id_lurah' => array(// second dropdown name
                        'table_name' => 'kelurahan', // table of state
                        'title' => 'nama_lurah', // state title
                        'id_field' => 'id_lurah', // table of state: primary key
                        'relate' => 'kecamatan_id_kecamatan', // table of state:
                        'data-placeholder' => 'Pilih Kelurahan/Desa' //dropdown's data-placeholder:
                        ),
                    );
                
                $config = array(
                            'main_table' => 'pelepasliaran',
                            'main_table_primary' => 'id_pelepasliaran',
                            "url" => base_url() .'/index.php/'. __CLASS__ . '/' . __FUNCTION__ . '/',
                            'ajax_loader' => base_url() . '/assets/grocery_crud/themes/datatables/css/images/small-loading.gif'
                        );
                $categories = new gc_dependent_select($crud, $fields, $config);
                $js = $categories->get_js();
                
                $output = $crud->render();        
                $output->output.= $js;
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_perolehan_satwa(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Perolehan Satwa";
            $req["url"]=site_url('lemkon/perolehan_satwa_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function perolehan_satwa_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('perolehan_satwa');                

                $crud->set_field_upload('upload_sat_dn','assets/uploads/lk/satdn');
                $crud->set_field_upload('upload_sk_peroleh','assets/uploads/lk/skperolehan');
                $crud->set_field_upload('upload_foto_utuh','assets/uploads/lk/fuperolehan');
                $crud->set_field_upload('upload_foto_spesifik','assets/uploads/lk/fsperolehan');

                //WARNING harus pakai session asal LK
                $crud->set_relation("id_individu_satwa","data_individu_satwa","{nama_panggilan_satwa} - {informasi_lk_umum_id_lk}/{master_satwa_nama_latin}");                
                $crud->set_relation("lk_tujuan_informasi_lk_umum_kode_lk", "informasi_lk_umum", "nama_lk");
                $crud->set_relation("master_perolehan_id_perolehan","master_perolehan","cara_perolehan");                                  
                
                $crud->unset_columns("id_perolehan");
                $crud->field_type('id_perolehan', 'hidden');

                $crud->display_as("id_individu_satwa","Nama Satwa")                
                ->display_as("lk_tujuan_informasi_lk_umum_kode_lk","LK Tujuan")
                ->display_as("master_perolehan_id_perolehan","Cara Perolehan")                                
                ;

                $crud->callback_before_insert(array($this,'perolehan_satwa_callback'));
                $crud->callback_before_update(array($this,'perolehan_satwa_callback'));
                            
                $output = $crud->render();                        
                $this->displayCRUD($output);

                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }
        public function monitoring_kematian_satwa(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Kematian Satwa";
            $req["url"]=site_url('lemkon/kematian_satwa_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function kematian_satwa_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('data_individu_satwa');

                $crud->fields('informasi_lk_umum_id_lk',
                                    'master_satwa_nama_latin',
                                    'nama_panggilan_satwa',
                                    'tanggal_kematian',
                                    'penyebab_kematian',                                    
                                    'upload_bap_kematian',
                                    'upload_foto_utuh_kematian',
                                    'upload_foto_spesifik_kematian');

                $crud->columns('informasi_lk_umum_id_lk',
                'master_satwa_nama_latin',
                'nama_panggilan_satwa',
                'tanggal_kematian',
                'penyebab_kematian',                                    
                'upload_bap_kematian',
                'upload_foto_utuh_kematian',
                'upload_foto_spesifik_kematian');

                $crud->set_relation("informasi_lk_umum_id_lk","informasi_lk_umum","nama_lk");                
                $crud->set_relation("master_satwa_nama_latin","master_satwa","{jenis_satwa} - {nama_latin}");  
                $crud->set_relation("penyebab_kematian","master_sebab_mati","nama_sebab");                

                //harus ada session LK - warning
                $crud->set_relation("nama_induk_jantan","data_individu_satwa","nama_panggilan_satwa",array('master_jenis_kelamin_id_jenis_kelamin' => 'J', 'informasi_lk_umum_id_lk' => 'TSII'), 'nama_panggilan_satwa ASC');
                $crud->set_relation("nama_induk_betina","data_individu_satwa","nama_panggilan_satwa",array('master_jenis_kelamin_id_jenis_kelamin' => 'B', 'informasi_lk_umum_id_lk' => 'TSII'), 'nama_panggilan_satwa ASC');

                $crud->display_as("informasi_lk_umum_id_lk","Nama LK")                
                ->display_as("master_satwa_nama_latin","Nama Latin")                
                ;

                $crud->set_field_upload('upload_bap','assets/uploads/lk/bapmati');
                $crud->set_field_upload('upload_foto_utuh','assets/uploads/lk/fumati');
                $crud->set_field_upload('upload_foto_spesifik','assets/uploads/lk/fsmati');

                $crud->unset_add();

                $crud->change_field_type('informasi_lk_umum_id_lk', 'readonly');
                $crud->change_field_type('master_satwa_nama_latin', 'readonly');
                $crud->change_field_type('nama_panggilan_satwa', 'readonly');
                
                $output = $crud->render();                        
                $this->displayCRUD($output);

                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_kelahiran_satwa(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Kelahiran Satwa";
            $req["url"]=site_url('lemkon/kelahiran_satwa_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function kelahiran_satwa_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('data_individu_satwa');

                $crud->fields('informasi_lk_umum_id_lk',
                                    'master_satwa_nama_latin',
                                    'nama_panggilan_satwa',
                                    'tanggal_lahir',
                                    'nama_induk_jantan',
                                    'nama_induk_betina',
                                    'upload_bap',
                                    'upload_foto_utuh',
                                    'upload_foto_spesifik');

                $crud->columns('informasi_lk_umum_id_lk',
                'master_satwa_nama_latin',
                'nama_panggilan_satwa',
                'tanggal_lahir',
                'nama_induk_jantan',
                'nama_induk_betina',
                'upload_bap',
                'upload_foto_utuh',
                'upload_foto_spesifik');

                $crud->set_relation("informasi_lk_umum_id_lk","informasi_lk_umum","nama_lk");                
                $crud->set_relation("master_satwa_nama_latin","master_satwa","{jenis_satwa} - {nama_latin}");                

                //harus ada session LK - warning
                $crud->set_relation("nama_induk_jantan","data_individu_satwa","nama_panggilan_satwa",array('master_jenis_kelamin_id_jenis_kelamin' => 'J', 'informasi_lk_umum_id_lk' => 'TSII'), 'nama_panggilan_satwa ASC');
                $crud->set_relation("nama_induk_betina","data_individu_satwa","nama_panggilan_satwa",array('master_jenis_kelamin_id_jenis_kelamin' => 'B', 'informasi_lk_umum_id_lk' => 'TSII'), 'nama_panggilan_satwa ASC');

                $crud->display_as("informasi_lk_umum_id_lk","Nama LK")                
                ->display_as("master_satwa_nama_latin","Nama Latin")                
                ;

                $crud->set_field_upload('upload_bap','assets/uploads/lk/baplahir');
                $crud->set_field_upload('upload_foto_utuh','assets/uploads/lk/fulahir');
                $crud->set_field_upload('upload_foto_spesifik','assets/uploads/lk/fslahir');

                $crud->unset_add();

                $crud->change_field_type('informasi_lk_umum_id_lk', 'readonly');
                $crud->change_field_type('master_satwa_nama_latin', 'readonly');
                $crud->change_field_type('nama_panggilan_satwa', 'readonly');
                
                $output = $crud->render();                        
                $this->displayCRUD($output);

                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_satwa_kelompok(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Dinamika Satwa Berkelompok (non-Identifikasi)";
            $req["url"]=site_url('lemkon/satwa_kelompok_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function satwa_kelompok_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('dinamika_satwa_noniden');

                $crud->field_type('id_satwa_noniden', 'hidden');

                $crud->set_relation("informasi_lk_umum_kode_lk","informasi_lk_umum","nama_lk");
                $crud->set_relation("master_taksa_id_taksa","master_taksa","nama_taksa");
                $crud->set_relation("master_status_konservasi_satwa_id_status","master_status_konservasi_satwa","nama_status");
                $crud->set_relation("master_satwa_nama_latin","master_satwa","{nama_latin} - {jenis_satwa}");
                //$crud->set_relation("non_lk_nama_instansi","non_lk","nama_instansi");
                //$crud->set_relation("lk_asal","informasi_lk_umum","nama_lk");
                $state = $crud->getState();
                if($state == 'edit')
                {
                    $crud->field_type('informasi_lk_umum_kode_lk', 'readonly');
                    $crud->field_type('master_satwa_nama_latin', 'readonly');
                }

                $crud->unset_columns('id_satwa_noniden');

                $crud->callback_before_insert(array($this,'satwa_kelompok_callback'));
                //$crud->callback_before_update(array($this,'satwa_kelompok_callback'));

                $crud->display_as("informasi_lk_umum_kode_lk","Nama LK")
                     ->display_as("master_taksa_id_taksa","Nama Taksa")
                     ->display_as("master_status_konservasi_satwa_id_status","Nama Status")
                     ->display_as("master_satwa_nama_latin","Nama Latin")
                    // ->display_as("non_lk_nama_instansi","Nama Instansi")
                ;

                /*$crud->set_rules('modal_awal','Modal Awal','integer');
                $crud->set_rules('pegawai','Pegawai','integer');
                $crud->set_rules('sarana','Sarana','integer');*/
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_individu_satwa(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Monitoring Data Individu Satwa";
            $req["url"]=site_url('lemkon/individu_satwa_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function individu_satwa_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('data_individu_satwa');

                $crud->display_as("informasi_lk_umum_id_lk","Id LK");

                $crud->set_relation("informasi_lk_umum_id_lk","informasi_lk_umum","nama_lk");
                $crud->set_relation("master_status_konservasi_satwa_id_status","master_status_konservasi_satwa","nama_status");
                $crud->set_relation("master_status_hukum_satwa_id_status","master_status_hukum_satwa","nama_status");
                $crud->set_relation("master_satwa_nama_latin","master_satwa","{nama_latin} - {jenis_satwa}");
                $crud->set_relation("master_jenis_kelamin_id_jenis_kelamin","master_jenis_kelamin","nama_jenis_kelamin");
                
                $crud->callback_before_insert(array($this,'individu_satwa_callback'));
                //$crud->callback_before_update(array($this,'individu_satwa_callback'));

                $crud->set_field_upload('file_asal_usul_bap','assets/uploads/lk/bapindsat');
                $crud->set_field_upload('pdf_upload_sk','assets/uploads/lk/skindsat');

                $crud->unset_fields('tanggal_lahir',
                                    'nama_induk_jantan',
                                    'nama_induk_betina',
                                    'upload_bap',
                                    'upload_foto_utuh',
                                    'upload_foto_spesifik',
                                    'tanggal_kematian',
                                    'penyebab_kematian',
                                    'upload_bap_kematian',
                                    'upload_foto_utuh_kematian',
                                    'upload_foto_spesifik_kematian'
                );
                
                $crud->unset_columns('id_individu_satwa',
                                    'tanggal_lahir',
                                    'nama_induk_jantan',
                                    'nama_induk_betina',
                                    'upload_bap',
                                    'upload_foto_utuh',
                                    'upload_foto_spesifik');

                $crud->field_type('id_individu_satwa', 'hidden');

                $crud->set_rules('informasi_lk_umum_id_lk','Nama LK','required');
                $crud->set_rules('master_satwa_nama_latin','Nama Latin','required');
                $crud->set_rules('no_identifikasi','No Identifikasi','required');

                $crud->display_as("informasi_lk_umum_id_lk","Nama LK")
                     ->display_as("master_status_konservasi_satwa_id_status","Status Konservasi Satwa")
                     ->display_as("master_status_hukum_satwa_id_status","Status Hukum Satwa")
                     ->display_as("master_satwa_nama_latin","Nama Latin")
                     ->display_as("master_jenis_kelamin_id_jenis_kelamin","Jenis Kelamin")
                     ->display_as("nomer_sk","No SK")
                     ;
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_investasi(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Monitoring Investasi";
            $req["url"]=site_url('lemkon/investasi_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function investasi_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('investasi');

                $crud->display_as("informasi_lk_umum_kode_lk","Nama LK");

                $crud->set_relation("informasi_lk_umum_kode_lk","informasi_lk_umum","nama_lk");

                /*$crud->set_rules('modal_awal','Modal Awal','integer');
                $crud->set_rules('pegawai','Pegawai','integer');
                $crud->set_rules('sarana','Sarana','integer');*/
                $crud->field_type('id_investasi', 'hidden');

                $crud->callback_before_insert(array($this,'investasi_callback'));
                $crud->callback_before_update(array($this,'investasi_callback'));
                $crud->callback_column('modal_awal',array($this,'currencyFormat'));
                $crud->callback_column('pegawai',array($this,'currencyFormat'));
                $crud->callback_column('sarana',array($this,'currencyFormat'));      
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function monitoring_informasi_lk_umum() {
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Informasi Lembaga Konservasi Umum";
            $req["url"]=site_url('lemkon/informasi_lk_umum_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function informasi_lk_umum_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('informasi_lk_umum');

                $crud->set_relation("master_institusi_lk_id_institusi_lk", "master_institusi_lk", "nama_institusi");
                $crud->set_relation("master_bentuk_lk_id_bentuk_lk", "master_bentuk_lk", "nama_bentuk_lk");

                $crud->columns("nama_lk", 
                              "master_institusi_lk_id_institusi_lk", 
                              "master_bentuk_lk_id_bentuk_lk",
                              "provinsi_id_prov",
                              "kabupaten_id_kab",
                              "sk_izin",
                              "tanggal_sk",
                              "luas_wilayah_ha");

                $crud->display_as("master_institusi_lk_id_institusi_lk","Institusi LK")
                     ->display_as("master_bentuk_lk_id_bentuk_lk","Bentuk LK")
                     ->display_as("provinsi_id_prov","Provinsi")
                     ->display_as("kabupaten_id_kab","Kabupaten")
                     ->display_as("kecamatan_id_kecamatan","Kecamatan")
                     ->display_as("kelurahan_id_lurah","Kelurahan")
                     ->display_as("luas_wilayah_ha","Luas Wilayah (Ha)")
                     ->display_as("id_lk","Id LK")
                     ->display_as("nama_lk","Nama LK")
                     ->display_as("npwp_lk","NPWP LK")
                     ->display_as("alamat_lk","Alamat LK")                     
                     ;
                
                $crud->set_rules('email','Email','valid_email');
                $crud->set_rules('link_website','Link website','valid_url');

                $crud->set_field_upload('sk_izin','assets/uploads/lk/sklkumum');

                $crud->set_relation("provinsi_id_prov", "provinsi", "nama_prov");
                $crud->set_relation("kabupaten_id_kab", "kabupaten", "nama_kab");
                $crud->set_relation("kecamatan_id_kecamatan", "kecamatan", "nama_kecamatan");
                $crud->set_relation("kelurahan_id_lurah", "kelurahan", "nama_lurah");

                $this->load->library('gc_dependent_select');
                
                $fields = array(
                        'provinsi_id_prov' => array(// first dropdown name
                        'table_name' => 'provinsi', // table of country
                        'title' => 'nama_prov', // country title
                        'relate' => null, // the first dropdown hasn't a relation
                        'data-placeholder' => 'Pilih Provinsi'
                        ),
                        'kabupaten_id_kab' => array(// second dropdown name
                        'table_name' => 'kabupaten', // table of state
                        'title' => 'nama_kab', // state title
                        'id_field' => 'id_kab', // table of state: primary key
                        'relate' => 'provinsi_id_prov', // table of state:
                        'data-placeholder' => 'Pilih Kabupaten/Kota' //dropdown's data-placeholder:
                        ),                        
                        'kecamatan_id_kecamatan' => array(// second dropdown name
                        'table_name' => 'kecamatan', // table of state
                        'title' => 'nama_kecamatan', // state title
                        'id_field' => 'id_kecamatan', // table of state: primary key
                        'relate' => 'kabupaten_id_kab', // table of state:
                        'data-placeholder' => 'Pilih Kecamatan' //dropdown's data-placeholder:
                        ),                    
                        'kelurahan_id_lurah' => array(// second dropdown name
                        'table_name' => 'kelurahan', // table of state
                        'title' => 'nama_lurah', // state title
                        'id_field' => 'id_lurah', // table of state: primary key
                        'relate' => 'kecamatan_id_kecamatan', // table of state:
                        'data-placeholder' => 'Pilih Kelurahan/Desa' //dropdown's data-placeholder:
                        ),
                    );
                
                $config = array(
                            'main_table' => 'informasi_lk_umum',
                            'main_table_primary' => 'id_lk',
                            "url" => base_url() .'/index.php/'. __CLASS__ . '/' . __FUNCTION__ . '/',
                            'ajax_loader' => base_url() . '/assets/grocery_crud/themes/datatables/css/images/small-loading.gif'
                        );
                $categories = new gc_dependent_select($crud, $fields, $config);
                $js = $categories->get_js();
                
                $output = $crud->render();        
                $output->output.= $js;
                $this->displayCRUD($output);

                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }    
//--------------------------------------------- End of Transactional Function -------------------------------------
public function index(){
    $this->monitoring_informasi_lk_umum();
}
//--------------------------------------------- Data Master Function -------------------------------------

        public function master_sebab_mati() {
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Penyebab Kematian Satwa";
            $req["url"]=site_url('lemkon/master_sebab_mati_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_sebab_mati_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_sebab_mati');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }  

        public function master_bentuk_lk() {
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Bentuk Lembaga Konservasi";
            $req["url"]=site_url('lemkon/master_bentuk_lk_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_bentuk_lk_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_bentuk_lk');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }                       

        public function master_institusi_lk(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Bentuk Institusi Lembaga Konservasi";
            $req["url"]=site_url('lemkon/master_institusi_lk_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_institusi_lk_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_institusi_lk');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function master_jenis_kelamin(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Jenis Kelamin";
            $req["url"]=site_url('lemkon/master_jenis_kelamin_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_jenis_kelamin_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_jenis_kelamin');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function master_kejadian(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Kejadian";
            $req["url"]=site_url('lemkon/master_kejadian_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_kejadian_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_kejadian');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function master_perolehan(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Perolehan";
            $req["url"]=site_url('lemkon/master_perolehan_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_perolehan_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_perolehan');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function master_satwa(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Satwa";
            $req["url"]=site_url('lemkon/master_satwa_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_satwa_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_satwa');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function master_status_hukum_satwa(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Status Hukum Satwa";
            $req["url"]=site_url('lemkon/master_status_hukum_satwa_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_status_hukum_satwa_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_status_hukum_satwa');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function master_status_konservasi_satwa(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Status Konservasi Satwa";
            $req["url"]=site_url('lemkon/master_status_konservasi_satwa_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_status_konservasi_satwa_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_status_konservasi_satwa');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }

        public function master_taksa(){
            if(strtolower($this->hakAkses)!="admin"){
                redirect("/login");
            }
            $req["judul"]="Data Master Taksa";
            $req["url"]=site_url('lemkon/master_taksa_ctl');
            $req["app"]="lk";
            $req["hak_akses"] = $this->login_model->hakAkses();
            $this->load->view("header", $req);
            $this->load->view("MstInstansiView", $req);
            $this->load->view("footer");
        }

        public function master_taksa_ctl(){
            if(strtolower($this->hakAkses)=="admin"){
                try{
                $crud=new grocery_CRUD();
                $crud->set_language("indonesian");          
                $crud->set_table('master_taksa');
                                
                $output = $crud->render();        
                $this->displayCRUD($output);
                }catch(Exception $e){
                    show_error($e->getMessage().' --- '.$e->getTraceAsString());
                }
            }
        }
//--------------------------------------------- End of Data Master Function -------------------------------------
        public function displayCRUD($output){
            $this->load->view("gc_view", $output);
        }

}